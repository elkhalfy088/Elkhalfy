# Add project specific ProGuard rules here.
-keep class com.elkhalfy.com.data.model.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn com.google.firebase.**
