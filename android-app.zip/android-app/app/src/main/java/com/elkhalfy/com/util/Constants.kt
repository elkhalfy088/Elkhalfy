package com.elkhalfy.com.util

object Constants {
    const val PREFS_NAME = "elkhalfy_prefs"
    const val KEY_ACTIVATION_CODE = "activation_code"
    const val KEY_DEVICE_ID = "device_id"

    // Firebase Realtime Database node names
    const val NODE_CODES = "codes"
    const val NODE_SERVERS = "servers"
    const val NODE_SETTINGS_APP = "settings/app"
    const val NODE_SETTINGS_SOCIAL = "settings/social"
    const val NODE_NOTIFICATIONS = "notifications"

    const val EXTRA_STREAM_URL = "extra_stream_url"
    const val EXTRA_STREAM_TITLE = "extra_stream_title"

    const val CONTENT_LIVE = "live"
    const val CONTENT_MOVIES = "movies"
    const val CONTENT_SERIES = "series"
}
