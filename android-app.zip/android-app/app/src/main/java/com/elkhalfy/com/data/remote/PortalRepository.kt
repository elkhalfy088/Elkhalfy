package com.elkhalfy.com.data.remote

import com.elkhalfy.com.data.model.Server
import com.elkhalfy.com.data.model.UiCategory
import com.elkhalfy.com.data.model.UiStream
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * Minimal Stalker/Ministra "Portal" client using the widely-documented STB HTTP API
 * (handshake -> get_profile -> genres -> ordered_list -> create_link).
 * This mirrors the behaviour of common open-source Stalker portal clients.
 */
class PortalRepository(private val server: Server) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()
    private val gson = Gson()
    private var token: String? = null

    private fun portalUrl() = server.url.trimEnd('/')

    private suspend fun request(path: String): String? = withContext(Dispatchers.IO) {
        try {
            val builder = Request.Builder()
                .url("${portalUrl()}$path")
                .addHeader("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C)")
                .addHeader("X-User-Agent", "Model: MAG250; Link: WiFi")
                .addHeader("Cookie", "mac=${server.macAddress}; stb_lang=en; timezone=Europe/London")
            token?.let { builder.addHeader("Authorization", "Bearer $it") }
            client.newCall(builder.build()).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext null
                resp.body?.string()
            }
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun ensureHandshake(): Boolean {
        if (token != null) return true
        val body = request("/portal.php?type=stb&action=handshake&JsRes=screen&token=&mac=${server.macAddress}") ?: return false
        return try {
            val json = gson.fromJson(body, Map::class.java)
            val js = json["js"] as? Map<*, *>
            token = js?.get("token")?.toString()
            token != null
        } catch (e: Exception) {
            false
        }
    }

    suspend fun getCategories(contentType: String): List<UiCategory> {
        if (!ensureHandshake()) return emptyList()
        // "type" identifies the portal module (itv | vod | series); "action" is the operation
        // within that module. Both must be set exactly once each, never duplicated.
        val type = when (contentType) {
            "movies" -> "vod"
            "series" -> "series"
            else -> "itv"
        }
        val action = if (type == "itv") "get_genres" else "get_categories"
        val body = request("/portal.php?type=$type&action=$action&mac=${server.macAddress}") ?: return emptyList()
        return try {
            val json = gson.fromJson(body, Map::class.java)
            val list = (json["js"] as? List<*>) ?: return emptyList()
            list.mapNotNull { item ->
                val m = item as? Map<*, *> ?: return@mapNotNull null
                val id = (m["id"] ?: m["category_id"])?.toString() ?: return@mapNotNull null
                val title = (m["title"] ?: m["name"])?.toString() ?: "بدون اسم"
                UiCategory(id, title)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getStreams(contentType: String, categoryId: String): List<UiStream> {
        if (!ensureHandshake()) return emptyList()
        val type = when (contentType) {
            "movies" -> "vod"
            "series" -> "series"
            else -> "itv"
        }
        val filterParam = if (type == "itv") "genre" else "category"
        val body = request("/portal.php?type=$type&action=get_ordered_list&$filterParam=$categoryId&mac=${server.macAddress}&p=1") ?: return emptyList()
        return try {
            val json = gson.fromJson(body, Map::class.java)
            val js = json["js"] as? Map<*, *>
            val list = (js?.get("data") as? List<*>) ?: return emptyList()
            list.mapNotNull { item ->
                val m = item as? Map<*, *> ?: return@mapNotNull null
                val id = (m["id"] ?: m["movie_id"])?.toString() ?: return@mapNotNull null
                val name = (m["name"] ?: m["title"])?.toString() ?: "بدون اسم"
                val cmd = m["cmd"]?.toString() ?: ""
                UiStream(id = id, name = name, iconUrl = m["screenshot_uri"]?.toString(), streamUrl = "portal_cmd::$cmd")
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Resolves the final playable URL for a portal item's raw "cmd" via create_link. */
    suspend fun resolvePlaybackUrl(cmd: String): String? {
        if (!ensureHandshake()) return null
        val encodedCmd = java.net.URLEncoder.encode(cmd, "UTF-8")
        val body = request("/portal.php?type=itv&action=create_link&cmd=$encodedCmd&mac=${server.macAddress}") ?: return null
        return try {
            val json = gson.fromJson(body, Map::class.java)
            val js = json["js"] as? Map<*, *>
            val link = js?.get("cmd")?.toString() ?: return null
            // Stalker often returns "ffmpeg http://real/url" - strip the launcher prefix if present.
            if (link.startsWith("ffmpeg ")) link.removePrefix("ffmpeg ").trim() else link
        } catch (e: Exception) {
            null
        }
    }
}
