package com.elkhalfy.com.ui.player

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.elkhalfy.com.databinding.ActivityPlayerBinding
import com.elkhalfy.com.util.Constants

/** Fullscreen ExoPlayer-based player used for live channels, movies, and series episodes. */
class PlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayerBinding
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val url = intent.getStringExtra(Constants.EXTRA_STREAM_URL).orEmpty()
        if (url.isBlank()) {
            showError("رابط التشغيل غير متوفر")
            return
        }
        preparePlayer(url)
    }

    private fun preparePlayer(url: String) {
        binding.playerLoading.visibility = android.view.View.VISIBLE
        val exoPlayer = ExoPlayer.Builder(this).build()
        binding.playerView.player = exoPlayer
        exoPlayer.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY || state == Player.STATE_BUFFERING) {
                    binding.playerLoading.visibility =
                        if (state == Player.STATE_BUFFERING) android.view.View.VISIBLE else android.view.View.GONE
                }
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                showError("تعذر تشغيل هذا المحتوى")
            }
        })
        exoPlayer.setMediaItem(MediaItem.fromUri(url))
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
        player = exoPlayer
    }

    private fun showError(msg: String) {
        binding.playerLoading.visibility = android.view.View.GONE
        binding.playerError.visibility = android.view.View.VISIBLE
        binding.playerError.text = msg
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
