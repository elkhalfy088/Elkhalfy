package com.elkhalfy.com.ui.splash

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.elkhalfy.com.data.local.Prefs
import com.elkhalfy.com.data.model.ActivationCode
import com.elkhalfy.com.data.remote.FirebaseRepository
import com.elkhalfy.com.databinding.ActivitySplashBinding
import com.elkhalfy.com.ui.activation.ActivationActivity
import com.elkhalfy.com.ui.maintenance.MaintenanceActivity
import com.elkhalfy.com.ui.main.MainActivity
import com.elkhalfy.com.util.DeviceUtils
import kotlinx.coroutines.launch

/**
 * Entry point: checks maintenance mode, then checks for a previously saved activation code.
 * Re-validates that code against Firebase every launch so disabling/expiring a code
 * immediately blocks access on next open.
 */
class SplashActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySplashBinding
    private val repo = FirebaseRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        lifecycleScope.launch {
            val settings = repo.getAppSettings()
            if (settings.maintenance?.enabled == true) {
                startActivity(Intent(this@SplashActivity, MaintenanceActivity::class.java).apply {
                    putExtra("message", settings.maintenance?.message ?: "")
                })
                finish()
                return@launch
            }

            val prefs = Prefs(this@SplashActivity)
            val savedCode = prefs.activationCode
            if (savedCode.isNullOrBlank()) {
                goToActivation()
                return@launch
            }

            val code = repo.getActivationCode(savedCode)
            if (code == null || !code.active || code.isExpired()) {
                prefs.clear()
                goToActivation()
                return@launch
            }

            val deviceId = DeviceUtils.getDeviceId(this@SplashActivity)
            val allowed = repo.registerDevice(savedCode, deviceId, DeviceUtils.deviceName(), code.maxDevices)
            if (!allowed) {
                prefs.clear()
                goToActivation()
                return@launch
            }

            startActivity(Intent(this@SplashActivity, MainActivity::class.java).apply {
                putExtra("serverId", code.serverId)
            })
            finish()
        }
    }

    private fun goToActivation() {
        startActivity(Intent(this, ActivationActivity::class.java))
        finish()
    }
}
