package com.elkhalfy.com.data.remote

import com.elkhalfy.com.data.model.ActivationCode
import com.elkhalfy.com.data.model.AppSettings
import com.elkhalfy.com.data.model.Maintenance
import com.elkhalfy.com.data.model.Server
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.FirebaseDatabase
import com.elkhalfy.com.util.Constants
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Single source of truth for everything read from / written to Firebase Realtime Database.
 * The dashboard (admin-dashboard/index.html) writes the same node structure this class reads.
 */
class FirebaseRepository {

    private val db = FirebaseDatabase.getInstance()

    suspend fun getActivationCode(code: String): ActivationCode? = suspendCancellableCoroutine { cont ->
        db.reference.child(Constants.NODE_CODES).child(code).get()
            .addOnSuccessListener { snap ->
                cont.resume(snapshotToActivationCode(snap))
            }
            .addOnFailureListener { cont.resume(null) }
    }

    suspend fun getServer(serverId: String): Server? = suspendCancellableCoroutine { cont ->
        db.reference.child(Constants.NODE_SERVERS).child(serverId).get()
            .addOnSuccessListener { snap ->
                if (!snap.exists()) { cont.resume(null); return@addOnSuccessListener }
                val s = Server(
                    id = serverId,
                    name = snap.child("name").getValue(String::class.java) ?: "",
                    type = snap.child("type").getValue(String::class.java) ?: "xtream",
                    url = snap.child("url").getValue(String::class.java) ?: "",
                    username = snap.child("username").getValue(String::class.java) ?: "",
                    password = snap.child("password").getValue(String::class.java) ?: "",
                    macAddress = snap.child("macAddress").getValue(String::class.java) ?: ""
                )
                cont.resume(s)
            }
            .addOnFailureListener { cont.resume(null) }
    }

    suspend fun getAppSettings(): AppSettings = suspendCancellableCoroutine { cont ->
        db.reference.child(Constants.NODE_SETTINGS_APP).get()
            .addOnSuccessListener { snap ->
                val maintenance = Maintenance(
                    enabled = snap.child("maintenance").child("enabled").getValue(Boolean::class.java) ?: false,
                    message = snap.child("maintenance").child("message").getValue(String::class.java) ?: ""
                )
                cont.resume(
                    AppSettings(
                        app_name = snap.child("app_name").getValue(String::class.java) ?: "",
                        logo_url = snap.child("logo_url").getValue(String::class.java) ?: "",
                        primary_color = snap.child("primary_color").getValue(String::class.java) ?: "#6C5CE7",
                        privacy_url = snap.child("privacy_url").getValue(String::class.java) ?: "",
                        maintenance = maintenance
                    )
                )
            }
            .addOnFailureListener { cont.resume(AppSettings()) }
    }

    /**
     * Registers this device against the code (enforces max device limit); returns true if allowed.
     * Uses a Realtime Database transaction on the whole `devices` map so concurrent activations
     * from multiple devices at the same instant cannot both slip past the maxDevices check
     * (a plain get-then-set is vulnerable to that race).
     */
    suspend fun registerDevice(code: String, deviceId: String, deviceName: String, maxDevices: Long): Boolean =
        suspendCancellableCoroutine { cont ->
            val devicesRef = db.reference.child(Constants.NODE_CODES).child(code).child("devices")
            devicesRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
                override fun doTransaction(currentData: com.google.firebase.database.MutableData): com.google.firebase.database.Transaction.Result {
                    @Suppress("UNCHECKED_CAST")
                    val current = (currentData.value as? Map<String, Any?>) ?: emptyMap()
                    if (current.containsKey(deviceId)) {
                        // already registered, nothing to change
                        return com.google.firebase.database.Transaction.success(currentData)
                    }
                    if (current.size.toLong() >= maxDevices) {
                        // abort: at capacity
                        return com.google.firebase.database.Transaction.abort()
                    }
                    currentData.child(deviceId).child("deviceName").value = deviceName
                    currentData.child(deviceId).child("addedAt").value = System.currentTimeMillis()
                    return com.google.firebase.database.Transaction.success(currentData)
                }

                override fun onComplete(
                    error: com.google.firebase.database.DatabaseError?,
                    committed: Boolean,
                    currentData: com.google.firebase.database.DataSnapshot?
                ) {
                    cont.resume(error == null && committed)
                }
            })
        }

    fun updateDeviceToken(code: String, deviceId: String, token: String) {
        db.reference.child(Constants.NODE_CODES).child(code).child("devices").child(deviceId)
            .child("fcmToken").setValue(token)
    }

    private fun snapshotToActivationCode(snap: DataSnapshot): ActivationCode? {
        if (!snap.exists()) return null
        val devicesMap = mutableMapOf<String, Any?>()
        snap.child("devices").children.forEach { c -> c.key?.let { devicesMap[it] = c.value } }
        val expiryRaw = snap.child("expiryDate").value
        return ActivationCode(
            serverId = snap.child("serverId").getValue(String::class.java) ?: "",
            active = snap.child("active").getValue(Boolean::class.java) ?: false,
            maxDevices = snap.child("maxDevices").getValue(Long::class.java) ?: 1L,
            expiryDate = expiryRaw,
            createdAt = snap.child("createdAt").getValue(Long::class.java) ?: 0L,
            devices = devicesMap
        )
    }
}
