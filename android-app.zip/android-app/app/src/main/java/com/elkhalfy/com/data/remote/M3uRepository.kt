package com.elkhalfy.com.data.remote

import com.elkhalfy.com.data.model.Server
import com.elkhalfy.com.data.model.UiCategory
import com.elkhalfy.com.data.model.UiStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

private data class M3uEntry(val name: String, val group: String, val logo: String?, val url: String)

/** Parses a remote M3U/M3U8 playlist into unified categories/streams grouped by #EXTGRP / group-title. */
class M3uRepository(private val server: Server) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private var cachedEntries: List<M3uEntry>? = null

    private suspend fun fetchEntries(): List<M3uEntry> {
        cachedEntries?.let { return it }
        return withContext(Dispatchers.IO) {
            val entries = mutableListOf<M3uEntry>()
            try {
                val req = Request.Builder().url(server.url).build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@use
                    val body = resp.body?.string() ?: return@use
                    var currentName = ""
                    var currentGroup = "عام"
                    var currentLogo: String? = null
                    body.lineSequence().forEach { rawLine ->
                        val line = rawLine.trim()
                        if (line.startsWith("#EXTINF")) {
                            currentGroup = Regex("group-title=\"([^\"]*)\"").find(line)?.groupValues?.get(1)?.ifBlank { "عام" } ?: "عام"
                            currentLogo = Regex("tvg-logo=\"([^\"]*)\"").find(line)?.groupValues?.get(1)
                            currentName = line.substringAfterLast(",").trim()
                        } else if (line.isNotEmpty() && !line.startsWith("#")) {
                            entries.add(M3uEntry(currentName.ifBlank { "بدون اسم" }, currentGroup, currentLogo, line))
                        }
                    }
                }
            } catch (e: Exception) {
                // network/parse failure -> return whatever was parsed so far
            }
            cachedEntries = entries
            entries
        }
    }

    suspend fun getCategories(): List<UiCategory> {
        val groups = fetchEntries().map { it.group }.distinct()
        return groups.mapIndexed { index, g -> UiCategory(index.toString(), g) }
    }

    suspend fun getStreams(categoryId: String): List<UiStream> {
        val groups = fetchEntries().map { it.group }.distinct()
        val groupName = groups.getOrNull(categoryId.toIntOrNull() ?: -1) ?: return emptyList()
        return fetchEntries().filter { it.group == groupName }.mapIndexed { i, e ->
            UiStream(id = "$categoryId-$i", name = e.name, iconUrl = e.logo, streamUrl = e.url)
        }
    }
}
