package com.elkhalfy.com.ui.maintenance

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.elkhalfy.com.databinding.ActivityMaintenanceBinding

class MaintenanceActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMaintenanceBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val message = intent.getStringExtra("message").orEmpty()
        binding.maintenanceMessage.text = message.ifBlank { getString(com.elkhalfy.com.R.string.maintenance_title) }
    }
}
