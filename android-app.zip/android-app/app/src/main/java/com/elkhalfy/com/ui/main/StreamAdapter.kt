package com.elkhalfy.com.ui.main

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.elkhalfy.com.data.model.UiStream
import com.elkhalfy.com.databinding.ItemStreamBinding

class StreamAdapter(
    private val onClick: (UiStream) -> Unit
) : RecyclerView.Adapter<StreamAdapter.VH>() {

    private val items = mutableListOf<UiStream>()

    fun submit(list: List<UiStream>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    inner class VH(val binding: ItemStreamBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): VH {
        val binding = ItemStreamBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.binding.streamName.text = item.name
        if (!item.iconUrl.isNullOrBlank()) {
            Glide.with(holder.binding.streamIcon).load(item.iconUrl).into(holder.binding.streamIcon)
        } else {
            holder.binding.streamIcon.setImageDrawable(null)
        }
        holder.binding.root.setOnClickListener { onClick(item) }
    }

    override fun getItemCount() = items.size
}
