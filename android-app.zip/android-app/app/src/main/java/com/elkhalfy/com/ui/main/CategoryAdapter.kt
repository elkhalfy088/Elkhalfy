package com.elkhalfy.com.ui.main

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.elkhalfy.com.R
import com.elkhalfy.com.data.model.UiCategory
import com.elkhalfy.com.databinding.ItemCategoryBinding

class CategoryAdapter(
    private val onClick: (UiCategory) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.VH>() {

    private val items = mutableListOf<UiCategory>()
    private var selectedId: String? = null

    fun submit(list: List<UiCategory>) {
        items.clear()
        items.addAll(list)
        selectedId = list.firstOrNull()?.id
        notifyDataSetChanged()
    }

    inner class VH(val binding: ItemCategoryBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): VH {
        val binding = ItemCategoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.binding.categoryName.text = item.name
        val isSelected = item.id == selectedId
        holder.binding.categoryName.setBackgroundResource(
            if (isSelected) R.color.primary else R.color.surface2
        )
        holder.binding.root.setOnClickListener {
            selectedId = item.id
            notifyDataSetChanged()
            onClick(item)
        }
    }

    override fun getItemCount() = items.size
}
