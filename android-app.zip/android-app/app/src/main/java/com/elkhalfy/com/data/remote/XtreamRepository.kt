package com.elkhalfy.com.data.remote

import com.elkhalfy.com.data.model.Server
import com.elkhalfy.com.data.model.UiCategory
import com.elkhalfy.com.data.model.UiStream
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/** Xtream Codes API client (player_api.php). */
class XtreamRepository(private val server: Server) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()
    private val gson = Gson()

    private fun baseUrl() = server.url.trimEnd('/')

    private fun playerApi(action: String, extra: String = ""): String {
        return "${baseUrl()}/player_api.php?username=${server.username}&password=${server.password}&action=$action$extra"
    }

    private suspend fun getJson(url: String): Any? = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url(url).build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext null
                val body = resp.body?.string() ?: return@withContext null
                gson.fromJson(body, Any::class.java)
            }
        } catch (e: Exception) {
            null
        }
    }

    suspend fun getCategories(contentType: String): List<UiCategory> {
        val action = when (contentType) {
            "movies" -> "get_vod_categories"
            "series" -> "get_series_categories"
            else -> "get_live_categories"
        }
        val result = getJson(playerApi(action)) as? List<*> ?: return emptyList()
        return result.mapNotNull { item ->
            val map = item as? Map<*, *> ?: return@mapNotNull null
            val id = map["category_id"]?.toString() ?: return@mapNotNull null
            val name = map["category_name"]?.toString() ?: "بدون اسم"
            UiCategory(id, name)
        }
    }

    suspend fun getStreams(contentType: String, categoryId: String): List<UiStream> {
        val action = when (contentType) {
            "movies" -> "get_vod_streams"
            "series" -> "get_series"
            else -> "get_live_streams"
        }
        val result = getJson(playerApi(action, "&category_id=$categoryId")) as? List<*> ?: return emptyList()
        return result.mapNotNull { item ->
            val map = item as? Map<*, *> ?: return@mapNotNull null
            when (contentType) {
                "movies" -> {
                    val id = map["stream_id"]?.toString() ?: return@mapNotNull null
                    UiStream(
                        id = id,
                        name = map["name"]?.toString() ?: "",
                        iconUrl = map["stream_icon"]?.toString(),
                        streamUrl = "${baseUrl()}/movie/${server.username}/${server.password}/$id.${map["container_extension"]?.toString() ?: "mp4"}"
                    )
                }
                "series" -> {
                    val id = map["series_id"]?.toString() ?: return@mapNotNull null
                    UiStream(
                        id = id,
                        name = map["name"]?.toString() ?: "",
                        iconUrl = map["cover"]?.toString(),
                        streamUrl = "",
                        isSeries = true
                    )
                }
                else -> {
                    val id = map["stream_id"]?.toString() ?: return@mapNotNull null
                    UiStream(
                        id = id,
                        name = map["name"]?.toString() ?: "",
                        iconUrl = map["stream_icon"]?.toString(),
                        streamUrl = "${baseUrl()}/live/${server.username}/${server.password}/$id.ts"
                    )
                }
            }
        }
    }

    /** Returns playable episode streams for a series (flattened across all seasons). */
    suspend fun getSeriesEpisodes(seriesId: String): List<UiStream> {
        val result = getJson(playerApi("get_series_info", "&series_id=$seriesId")) as? Map<*, *> ?: return emptyList()
        val seasons = result["episodes"] as? Map<*, *> ?: return emptyList()
        val list = mutableListOf<UiStream>()
        seasons.forEach { (_, eps) ->
            (eps as? List<*>)?.forEach { epAny ->
                val ep = epAny as? Map<*, *> ?: return@forEach
                val id = ep["id"]?.toString() ?: return@forEach
                val title = ep["title"]?.toString() ?: "الحلقة $id"
                val ext = ep["container_extension"]?.toString() ?: "mp4"
                list.add(
                    UiStream(
                        id = id,
                        name = title,
                        iconUrl = null,
                        streamUrl = "${baseUrl()}/series/${server.username}/${server.password}/$id.$ext"
                    )
                )
            }
        }
        return list
    }
}
