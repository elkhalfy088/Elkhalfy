package com.elkhalfy.com.ui.main

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.elkhalfy.com.R
import com.elkhalfy.com.data.local.Prefs
import com.elkhalfy.com.data.model.Server
import com.elkhalfy.com.data.model.UiCategory
import com.elkhalfy.com.data.model.UiStream
import com.elkhalfy.com.data.remote.FirebaseRepository
import com.elkhalfy.com.data.remote.M3uRepository
import com.elkhalfy.com.data.remote.PortalRepository
import com.elkhalfy.com.data.remote.XtreamRepository
import com.elkhalfy.com.databinding.ActivityMainBinding
import com.elkhalfy.com.ui.player.PlayerActivity
import com.elkhalfy.com.util.Constants
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.launch

/** Main content browser: live channels / movies / series, driven by whichever server the active code points to. */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val repo = FirebaseRepository()

    private var server: Server? = null
    private var xtream: XtreamRepository? = null
    private var m3u: M3uRepository? = null
    private var portal: PortalRepository? = null

    private var currentContentType: String = Constants.CONTENT_LIVE
    private val categoryAdapter = CategoryAdapter { onCategorySelected(it) }
    private val streamAdapter = StreamAdapter { onStreamSelected(it) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        binding.categoriesRecycler.layoutManager = LinearLayoutManager(this)
        binding.categoriesRecycler.adapter = categoryAdapter
        binding.streamsRecycler.layoutManager = LinearLayoutManager(this)
        binding.streamsRecycler.adapter = streamAdapter

        binding.swipeRefresh.setOnRefreshListener { loadCategories() }

        binding.bottomNav.setOnItemSelectedListener { item ->
            currentContentType = when (item.itemId) {
                R.id.nav_movies -> Constants.CONTENT_MOVIES
                R.id.nav_series -> Constants.CONTENT_SERIES
                else -> Constants.CONTENT_LIVE
            }
            loadCategories()
            true
        }

        subscribeToNotifications()

        val serverId = intent.getStringExtra("serverId")
        if (serverId.isNullOrBlank()) {
            Toast.makeText(this, getString(R.string.activation_server_missing), Toast.LENGTH_LONG).show()
            finish()
            return
        }
        lifecycleScope.launch {
            val s = repo.getServer(serverId)
            if (s == null) {
                Toast.makeText(this@MainActivity, getString(R.string.activation_server_missing), Toast.LENGTH_LONG).show()
                finish()
                return@launch
            }
            server = s
            when (s.type) {
                "m3u" -> m3u = M3uRepository(s)
                "portal" -> portal = PortalRepository(s)
                else -> xtream = XtreamRepository(s)
            }
            loadCategories()
        }
    }

    override fun onStart() {
        super.onStart()
        FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            val code = Prefs(this).activationCode ?: return@addOnSuccessListener
            repo.updateDeviceToken(code, com.elkhalfy.com.util.DeviceUtils.getDeviceId(this), token)
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.mainProgress.visibility = if (loading) android.view.View.VISIBLE else android.view.View.GONE
        binding.swipeRefresh.isRefreshing = false
    }

    private fun loadCategories() {
        setLoading(true)
        lifecycleScope.launch {
            val categories: List<UiCategory> = when {
                xtream != null -> xtream!!.getCategories(currentContentType)
                m3u != null -> m3u!!.getCategories()
                portal != null -> portal!!.getCategories(currentContentType)
                else -> emptyList()
            }
            setLoading(false)
            categoryAdapter.submit(categories)
            binding.emptyText.visibility = if (categories.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
            binding.emptyText.text = getString(R.string.network_error)
            categories.firstOrNull()?.let { onCategorySelected(it) } ?: streamAdapter.submit(emptyList())
        }
    }

    private fun onCategorySelected(category: UiCategory) {
        setLoading(true)
        lifecycleScope.launch {
            val streams: List<UiStream> = when {
                xtream != null -> xtream!!.getStreams(currentContentType, category.id)
                m3u != null -> m3u!!.getStreams(category.id)
                portal != null -> portal!!.getStreams(currentContentType, category.id)
                else -> emptyList()
            }
            setLoading(false)
            streamAdapter.submit(streams)
        }
    }

    private fun onStreamSelected(stream: UiStream) {
        if (stream.isSeries) {
            lifecycleScope.launch {
                val episodes = xtream?.getSeriesEpisodes(stream.id) ?: emptyList()
                if (episodes.isEmpty()) {
                    Toast.makeText(this@MainActivity, getString(R.string.network_error), Toast.LENGTH_SHORT).show()
                } else {
                    streamAdapter.submit(episodes)
                }
            }
            return
        }
        lifecycleScope.launch {
            var url = stream.streamUrl
            if (url.startsWith("portal_cmd::")) {
                val cmd = url.removePrefix("portal_cmd::")
                url = portal?.resolvePlaybackUrl(cmd) ?: ""
            }
            if (url.isBlank()) {
                Toast.makeText(this@MainActivity, getString(R.string.network_error), Toast.LENGTH_SHORT).show()
                return@launch
            }
            startActivity(android.content.Intent(this@MainActivity, PlayerActivity::class.java).apply {
                putExtra(Constants.EXTRA_STREAM_URL, url)
                putExtra(Constants.EXTRA_STREAM_TITLE, stream.name)
            })
        }
    }

    /** Listens for admin-sent notifications (targeted at "all" or this device's specific code) while the app is open. */
    private fun subscribeToNotifications() {
        val myCode = Prefs(this).activationCode ?: return
        FirebaseDatabase.getInstance().reference.child(Constants.NODE_NOTIFICATIONS)
            .limitToLast(1)
            .addChildEventListener(object : com.google.firebase.database.ChildEventListener {
                override fun onChildAdded(snapshot: com.google.firebase.database.DataSnapshot, previousChildName: String?) {
                    val target = snapshot.child("target").getValue(String::class.java) ?: "all"
                    if (target != "all" && target != myCode) return
                    val title = snapshot.child("title").getValue(String::class.java) ?: return
                    val body = snapshot.child("body").getValue(String::class.java) ?: ""
                    Toast.makeText(this@MainActivity, "$title: $body", Toast.LENGTH_LONG).show()
                }
                override fun onChildChanged(snapshot: com.google.firebase.database.DataSnapshot, previousChildName: String?) {}
                override fun onChildRemoved(snapshot: com.google.firebase.database.DataSnapshot) {}
                override fun onChildMoved(snapshot: com.google.firebase.database.DataSnapshot, previousChildName: String?) {}
                override fun onCancelled(error: com.google.firebase.database.DatabaseError) {}
            })
    }
}
