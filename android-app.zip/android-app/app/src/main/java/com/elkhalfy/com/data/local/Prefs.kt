package com.elkhalfy.com.data.local

import android.content.Context
import com.elkhalfy.com.util.Constants

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)

    var activationCode: String?
        get() = sp.getString(Constants.KEY_ACTIVATION_CODE, null)
        set(value) = sp.edit().putString(Constants.KEY_ACTIVATION_CODE, value).apply()

    fun clear() = sp.edit().remove(Constants.KEY_ACTIVATION_CODE).apply()
}
