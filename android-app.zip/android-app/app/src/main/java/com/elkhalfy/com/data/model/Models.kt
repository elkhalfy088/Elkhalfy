package com.elkhalfy.com.data.model

/** Mirrors /servers/{id} in Firebase Realtime Database. */
data class Server(
    var id: String = "",
    var name: String = "",
    var type: String = "xtream", // xtream | m3u | portal
    var url: String = "",
    var username: String = "",
    var password: String = "",
    var macAddress: String = "",
    var createdAt: Long = 0L
)

/** Mirrors /codes/{code} in Firebase Realtime Database. */
data class ActivationCode(
    var serverId: String = "",
    var active: Boolean = false,
    var maxDevices: Long = 1,
    var expiryDate: Any? = "unlimited", // "unlimited" (String) or millis (Long/Double)
    var createdAt: Long = 0L,
    var devices: Map<String, Any?>? = null
) {
    fun isExpired(): Boolean {
        val exp = expiryDate
        if (exp == null || exp == "unlimited") return false
        val millis = when (exp) {
            is Long -> exp
            is Double -> exp.toLong()
            is Int -> exp.toLong()
            else -> return false
        }
        return System.currentTimeMillis() > millis
    }
}

/** Mirrors /settings/app in Firebase Realtime Database. */
data class AppSettings(
    var app_name: String = "",
    var logo_url: String = "",
    var primary_color: String = "#6C5CE7",
    var privacy_url: String = "",
    var maintenance: Maintenance? = null
)

data class Maintenance(
    var enabled: Boolean = false,
    var message: String = ""
)

data class SocialLinks(
    var telegram: String = "",
    var whatsapp: String = "",
    var facebook: String = "",
    var instagram: String = "",
    var youtube: String = "",
    var website: String = ""
)

/** Unified UI model for a playable category, regardless of the source server type. */
data class UiCategory(
    val id: String,
    val name: String
)

/** Unified UI model for a playable stream/movie/series item. */
data class UiStream(
    val id: String,
    val name: String,
    val iconUrl: String?,
    val streamUrl: String,
    val isSeries: Boolean = false
)
