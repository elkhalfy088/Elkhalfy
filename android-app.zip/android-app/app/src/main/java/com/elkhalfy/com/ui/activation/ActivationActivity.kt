package com.elkhalfy.com.ui.activation

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.elkhalfy.com.R
import com.elkhalfy.com.data.local.Prefs
import com.elkhalfy.com.data.remote.FirebaseRepository
import com.elkhalfy.com.databinding.ActivityActivationBinding
import com.elkhalfy.com.ui.main.MainActivity
import com.elkhalfy.com.util.DeviceUtils
import kotlinx.coroutines.launch

/** Requests and validates the activation code required before any content can be browsed. */
class ActivationActivity : AppCompatActivity() {

    private lateinit var binding: ActivityActivationBinding
    private val repo = FirebaseRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityActivationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.activateButton.setOnClickListener { attemptActivation() }
    }

    private fun attemptActivation() {
        val code = binding.codeInput.text?.toString()?.trim()?.uppercase().orEmpty()
        binding.errorText.text = ""
        if (code.isEmpty()) {
            binding.errorText.text = getString(R.string.activation_invalid)
            return
        }
        setLoading(true)
        lifecycleScope.launch {
            val activation = repo.getActivationCode(code)
            if (activation == null) {
                showError(getString(R.string.activation_invalid))
                return@launch
            }
            if (!activation.active) {
                showError(getString(R.string.activation_disabled))
                return@launch
            }
            if (activation.isExpired()) {
                showError(getString(R.string.activation_expired))
                return@launch
            }
            if (activation.serverId.isBlank()) {
                showError(getString(R.string.activation_server_missing))
                return@launch
            }
            val deviceId = DeviceUtils.getDeviceId(this@ActivationActivity)
            val allowed = repo.registerDevice(code, deviceId, DeviceUtils.deviceName(), activation.maxDevices)
            if (!allowed) {
                showError(getString(R.string.activation_limit))
                return@launch
            }

            Prefs(this@ActivationActivity).activationCode = code
            setLoading(false)
            startActivity(Intent(this@ActivationActivity, MainActivity::class.java).apply {
                putExtra("serverId", activation.serverId)
            })
            finish()
        }
    }

    private fun showError(msg: String) {
        setLoading(false)
        binding.errorText.text = msg
    }

    private fun setLoading(loading: Boolean) {
        binding.progress.visibility = if (loading) android.view.View.VISIBLE else android.view.View.GONE
        binding.activateButton.isEnabled = !loading
    }
}
