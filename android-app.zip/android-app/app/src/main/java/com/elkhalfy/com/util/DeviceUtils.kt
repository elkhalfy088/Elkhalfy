package com.elkhalfy.com.util

import android.content.Context
import android.provider.Settings
import java.util.UUID

object DeviceUtils {

    /** Stable per-install device identifier used to enforce the max-devices limit per code. */
    fun getDeviceId(context: Context): String {
        val prefs = context.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
        var id = prefs.getString(Constants.KEY_DEVICE_ID, null)
        if (id == null) {
            id = try {
                Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
                    ?: UUID.randomUUID().toString()
            } catch (e: Exception) {
                UUID.randomUUID().toString()
            }
            // Firebase keys cannot contain '.', '#', '$', '[', ']', '/'
            id = id.replace(Regex("[.#$\\[\\]/]"), "_")
            prefs.edit().putString(Constants.KEY_DEVICE_ID, id).apply()
        }
        return id
    }

    fun deviceName(): String {
        return android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL
    }
}
