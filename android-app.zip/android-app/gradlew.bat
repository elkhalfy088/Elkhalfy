@rem Gradle startup script for Windows. Regenerate with:
@rem   gradle wrapper --gradle-version 8.7
@echo off
set DIRNAME=%~dp0
set APP_HOME=%DIRNAME%
set CLASSPATH=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
if not exist "%CLASSPATH%" (
  echo ERROR: gradle-wrapper.jar not found. Run "gradle wrapper --gradle-version 8.7" first.
  exit /b 1
)
"%JAVA_HOME%\bin\java.exe" -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*
