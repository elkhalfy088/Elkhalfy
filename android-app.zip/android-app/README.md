# Elkhalfy — تطبيق IPTV + لوحة تحكم Firebase

مشروع كامل يتكوّن من:

1. **تطبيق أندرويد (Kotlin/Gradle)** في هذا المجلد `android-app/` — جاهز للرفع إلى GitHub وربطه بـ Bitrise لبنائه كـ APK/AAB.
2. **لوحة تحكم** في `admin-dashboard/index.html` — ملف واحد فقط (HTML+CSS+JS) يعمل بالكامل عبر Firebase بدون أي سيرفر خلفي.

كل من التطبيق واللوحة يقرآن/يكتبان في نفس مشروع Firebase الذي زوّدتني به.

---

## 1) هيكلة قاعدة البيانات (Firebase Realtime Database)

```
/servers/{serverId}
    name, type ("xtream" | "m3u" | "portal"), url, username, password, macAddress, createdAt

/codes/{CODE}
    serverId, active (bool), maxDevices (int), expiryDate ("unlimited" | timestamp),
    createdAt, devices/{deviceId}: { deviceName, addedAt, fcmToken }

/settings/app
    app_name, logo_url, primary_color, privacy_url, maintenance: { enabled, message }

/settings/social
    telegram, whatsapp, facebook, instagram, youtube, website

/notifications/{id}
    title, body, target ("all" | "<CODE>"), createdAt, sentBy

/logs/{id}
    action, details, admin, timestamp
```

اللوحة تنشئ وتقرأ هذه العقد تلقائيًا — لا حاجة لإنشائها يدويًا.

## 2) تشغيل لوحة التحكم

- افتح `admin-dashboard/index.html` مباشرة في المتصفح، أو استضفه مجانًا على **Firebase Hosting** (`firebase deploy`).
- من Firebase Console → Authentication → Sign-in method: فعّل "Email/Password".
- من نفس الصفحة → Users: أضف مستخدمًا (بريد + كلمة مرور) لتستخدمه لتسجيل الدخول إلى اللوحة.
- من Realtime Database → Rules: اربط القراءة/الكتابة بحساب مصادَق (مثال مبدئي، عدّله بما يناسبك أمنيًا):

```json
{
  "rules": {
    "servers": { ".read": true, ".write": "auth != null" },
    "codes": {
      "$code": {
        ".read": true,
        "devices": {
          "$deviceId": {
            ".write": "auth != null || (!data.exists() && newData.exists() && (!root.child('codes').child($code).child('devices').exists() || root.child('codes').child($code).child('devices').val().length() < root.child('codes').child($code).child('maxDevices').val()))"
          }
        },
        ".write": "auth != null"
      }
    },
    "settings": { ".read": true, ".write": "auth != null" },
    "notifications": { ".read": true, ".write": "auth != null" },
    "logs": { ".read": "auth != null", ".write": "auth != null" }
  }
}
```

> **ملاحظات أمنية مهمة:**
> - لوحة التحكم **لا تحتوي على شاشة "إنشاء حساب"** — الدخول الوحيد هو تسجيل الدخول بحساب أنشأته أنت يدويًا من Firebase Console. لذلك أي مستخدم مصادَق (`auth != null`) هو فعليًا مدير موثوق بحكم أنك من أضافه بنفسك؛ لا تُفعّل تسجيل الحسابات الذاتي أبدًا في مشروع Firebase هذا.
> - التطبيق (بدون تسجيل دخول) يحتاج فقط قراءة على `codes/{code}` و `servers/{serverId}`، وكتابة على `codes/{code}/devices/{deviceId}` عند أول تفعيل لكل جهاز. القاعدة أعلاه تسمح بإضافة جهاز جديد فقط إذا لم يكن موجودًا ولم يتجاوز العدد `maxDevices`، وتمنع أي تعديل آخر بدون مصادقة.
> - جانب العميل (التطبيق) يستخدم أيضًا معاملة (`Transaction`) عند تسجيل الجهاز لمنع تجاوز الحد الأقصى عند التفعيل من جهازين في نفس اللحظة، لكن قواعد RTDB أعلاه هي خط الدفاع الحقيقي — لا تعتمد على منطق التطبيق فقط.
> - رغم هذه القواعد، النظام يبقى "بلا خادم" بالتصميم كما طلبت؛ لضمان حماية كاملة 100% ضد التلاعب المباشر بـ API يفضَّل مستقبلًا إضافة Cloud Function خفيفة للتحقق من الكود (نفس الاقتراح المذكور في القسم الخاص بالإشعارات).

## 3) بناء تطبيق أندرويد عبر Bitrise

1. أنشئ مستودع GitHub وارفع محتوى هذا المشروع بالكامل إليه (بما فيه `android-app/`).
2. من https://app.bitrise.io اربط المستودع، واختر "Android" كنوع المشروع.
3. تأكد أن ملف `bitrise.yml` الموجود هنا هو المستخدم (أو انسخ محتواه إلى الإعداد الظاهر في الرابط الذي أرسلته).
4. عند أول تشغيل، الخطوة "Ensure Gradle wrapper exists" تُنشئ ملف `gradle-wrapper.jar` تلقائيًا على السيرفر (لم نلتزم برفع ملف .jar ثنائي ضمن الكود).
5. عند نجاح البناء ستجد ملف APK/AAB جاهزًا ضمن Artifacts في Bitrise.

للتوقيع (Signing) لنشر التطبيق على Google Play، أضف مفتاح التوقيع (Keystore) كـ "Generic File Storage" في Bitrise واستخدم خطوة `sign-apk`/`android-sign`.

### حل مشكلة "gradlew: file does not exist" على Bitrise

ملف `gradle/wrapper/gradle-wrapper.jar` **مُضمَّن فعليًا** الآن في المستودع (وليس فقط الأسكريبت النصي)، فـ `./gradlew` يعمل من أول تشغيل بدون أي خطوة إضافية.

إن ظهر الخطأ رغم ذلك، فالسبب المرجّح أن تهيئة الـ Workflow على لوحة Bitrise (تبويب **Workflow Editor → Code**) لا تقرأ فعليًا ملف `bitrise.yml` الموجود في هذا المستودع، بل تستخدم إعدادًا منفصلًا أنشأه معالج "Scan a repository" التلقائي (غالبًا باسم `build_apk`). للتأكد:

1. من صفحة التطبيق في Bitrise → **App Settings → Configuration**، فعّل خيار **"bitrise.yml stored in your git repository"** وحدّد المسار `android-app/bitrise.yml`، بدل الاعتماد على الإعداد المولَّد تلقائيًا.
2. أو، إن كنت تفضّل الإبقاء على تهيئة لوحة Bitrise كما هي، تأكد من أن خطوة **Install missing Android SDK components** لديها `gradlew_path` مضبوطًا على `android-app/gradlew` (أو `$PROJECT_LOCATION/gradlew`).
3. أعد تشغيل البناء بعد التأكد من أي من الخيارين أعلاه.

## 4) ربط التطبيق بمشروع Firebase

- `app/google-services.json` معبأ ببيانات مشروعك (`sefyan-46115`) واسم الحزمة `com.elkhalfy.com`.
- إن رغبت باستخدام Firebase Cloud Messaging لاحقًا بشكل كامل (Push حقيقي حتى مع إغلاق التطبيق)، سجّل التطبيق في Firebase Console → Project Settings → Add App (Android) بنفس اسم الحزمة، ونزّل `google-services.json` الرسمي الجديد الذي يحتوي `mobilesdk_app_id` صحيح، ثم استبدل الملف الحالي به.

## 5) التوسّع مستقبلًا: إشعارات Push حقيقية

حاليًا الإشعارات تُخزَّن في `/notifications` ويستقبلها التطبيق فورًا **أثناء تشغيله** (بدون سيرفر). لإرسال Push حقيقي يصل حتى مع إغلاق التطبيق، يلزم عنصر موثوق (Cloud Function صغيرة أو أي خادم بسيط) يستدعي Firebase Admin SDK عند إضافة عنصر جديد في `/notifications` ويرسله عبر FCM إلى التوكنات المخزّنة في `codes/{code}/devices/{id}/fcmToken`. لوحة التحكم لن تحتاج أي تعديل عند إضافة هذه الخطوة مستقبلًا — فقط أضف Cloud Function مستمعة على `/notifications`.

## 6) بنية الكود (Android)

```
app/src/main/java/com/elkhalfy/com/
  App.kt                     تهيئة عامة
  data/model/                نماذج البيانات (Server, ActivationCode, ...)
  data/remote/FirebaseRepository.kt   كل التعاملات مع Realtime Database
  data/remote/XtreamRepository.kt     Xtream Codes API
  data/remote/M3uRepository.kt        تحليل ملفات M3U/M3U8
  data/remote/PortalRepository.kt     بروتوكول Stalker Portal (MAC)
  data/local/Prefs.kt         تخزين كود التفعيل محليًا
  ui/splash/                  فحص الصيانة + الكود المحفوظ
  ui/activation/              شاشة إدخال كود التفعيل
  ui/maintenance/             شاشة الصيانة
  ui/main/                    تصفح القنوات/الأفلام/المسلسلات
  ui/player/                  مشغل الفيديو (ExoPlayer/Media3)
  fcm/FcmService.kt           استقبال الإشعارات وتحديث التوكن
```
